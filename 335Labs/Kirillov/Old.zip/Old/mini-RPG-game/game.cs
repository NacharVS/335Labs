﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _335Labs.Kirillov.mini_RPG_game
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
